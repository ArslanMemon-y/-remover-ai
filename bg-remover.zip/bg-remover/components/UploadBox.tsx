"use client";

import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { motion, AnimatePresence } from "framer-motion";
import {
  CloudUpload,
  ImageIcon,
  AlertCircle,
  FileImage,
} from "lucide-react";

interface UploadBoxProps {
  onUpload: (file: File) => void;
  isLoading: boolean;
}

const MAX_SIZE_MB = 10;
const ACCEPTED_TYPES = {
  "image/png": [".png"],
  "image/jpeg": [".jpg", ".jpeg"],
  "image/webp": [".webp"],
};

export default function UploadBox({ onUpload, isLoading }: UploadBoxProps) {
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const processFile = useCallback(
    (file: File) => {
      setError(null);

      // Validate size
      if (file.size > MAX_SIZE_MB * 1024 * 1024) {
        setError(`File too large. Max size is ${MAX_SIZE_MB}MB.`);
        return;
      }

      // Show preview
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(file);

      onUpload(file);
    },
    [onUpload]
  );

  const onDrop = useCallback(
    (acceptedFiles: File[], rejectedFiles: { errors: { message: string }[] }[]) => {
      setDragOver(false);
      if (rejectedFiles.length > 0) {
        const err = rejectedFiles[0].errors[0];
        if (err.message.includes("file-too-large")) {
          setError(`File too large. Max size is ${MAX_SIZE_MB}MB.`);
        } else {
          setError("Invalid file type. Please upload PNG, JPG, or WEBP.");
        }
        return;
      }
      if (acceptedFiles.length > 0) {
        processFile(acceptedFiles[0]);
      }
    },
    [processFile]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxFiles: 1,
    maxSize: MAX_SIZE_MB * 1024 * 1024,
    disabled: isLoading,
    onDragEnter: () => setDragOver(true),
    onDragLeave: () => setDragOver(false),
  });

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Section heading */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h2
          className="text-3xl md:text-4xl font-bold text-white mb-3"
          style={{ fontFamily: "'Clash Display', sans-serif" }}
        >
          Upload Your Image
        </h2>
        <p className="text-[#8B92B3] text-base">
          Drag & drop or click to select — AI does the rest
        </p>
      </motion.div>

      {/* Drop zone */}
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        {...getRootProps()}
        className={`upload-zone relative glass rounded-3xl p-12 md:p-16 cursor-pointer transition-all duration-300 text-center group ${
          dragOver || isDragActive
            ? "drag-over border-cyan-400"
            : "border-border"
        } ${isLoading ? "opacity-60 cursor-not-allowed" : ""}`}
      >
        <input {...getInputProps()} />

        {/* Animated ring on drag */}
        <AnimatePresence>
          {(dragOver || isDragActive) && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 rounded-3xl border-2 border-cyan-400 glow-cyan pointer-events-none"
            />
          )}
        </AnimatePresence>

        {/* Upload icon */}
        <motion.div
          animate={
            dragOver || isDragActive
              ? { y: -8, scale: 1.1 }
              : { y: 0, scale: 1 }
          }
          transition={{ duration: 0.3 }}
          className="flex justify-center mb-6"
        >
          <div
            className={`w-20 h-20 rounded-2xl flex items-center justify-center transition-all duration-300 ${
              dragOver || isDragActive
                ? "bg-cyan-400/20 glow-cyan"
                : "bg-card border border-border group-hover:border-border-bright"
            }`}
          >
            <CloudUpload
              className={`w-9 h-9 transition-colors duration-300 ${
                dragOver || isDragActive ? "text-cyan-400" : "text-[#4A5070] group-hover:text-[#8B92B3]"
              }`}
            />
          </div>
        </motion.div>

        {/* Text content */}
        <AnimatePresence mode="wait">
          {dragOver || isDragActive ? (
            <motion.div
              key="drag"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
            >
              <p className="text-xl font-semibold text-cyan-400 mb-2">
                Drop your image here
              </p>
              <p className="text-[#4A5070] text-sm">Release to start processing</p>
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
            >
              <p className="text-xl font-semibold text-white mb-2">
                Drag & drop your image here
              </p>
              <p className="text-[#8B92B3] text-sm mb-6">
                or click to browse from your device
              </p>

              {/* Browse button */}
              <div className="inline-flex items-center gap-2 px-6 py-3 rounded-xl btn-primary text-sm font-semibold text-white mb-8">
                <FileImage className="w-4 h-4" />
                Choose Image
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Supported formats */}
        <div className="flex items-center justify-center gap-3 flex-wrap">
          {["PNG", "JPG", "JPEG", "WEBP"].map((fmt) => (
            <div
              key={fmt}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card border border-border text-[10px] font-bold tracking-widest text-[#4A5070] uppercase"
            >
              <ImageIcon className="w-3 h-3" />
              {fmt}
            </div>
          ))}
          <div className="text-[#4A5070] text-xs">· Max {MAX_SIZE_MB}MB</div>
        </div>
      </motion.div>

      {/* Error message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4 flex items-center gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Helper tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-8 grid grid-cols-3 gap-3"
      >
        {[
          { icon: "🖼️", tip: "Works with portraits, products & objects" },
          { icon: "⚡", tip: "Results ready in under 3 seconds" },
          { icon: "🔒", tip: "Images are deleted after processing" },
        ].map((item) => (
          <div
            key={item.tip}
            className="glass rounded-2xl p-4 border border-border text-center"
          >
            <div className="text-2xl mb-2">{item.icon}</div>
            <p className="text-xs text-[#4A5070] leading-relaxed">{item.tip}</p>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
