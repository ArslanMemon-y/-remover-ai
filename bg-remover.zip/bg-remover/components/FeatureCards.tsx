"use client";

import { motion } from "framer-motion";
import { Zap, ImageDown, Wand2, Shield, Layers, DownloadCloud } from "lucide-react";

const features = [
  {
    icon: Zap,
    color: "cyan",
    colorClass: "text-cyan-400",
    bgClass: "bg-cyan-400/10 border-cyan-400/20",
    glowClass: "group-hover:glow-cyan",
    title: "Lightning Fast AI",
    description:
      "Our deep learning model processes your image in under 3 seconds. No waiting, no queue — instant results every time.",
    badge: "< 3 seconds",
  },
  {
    icon: ImageDown,
    color: "violet",
    colorClass: "text-violet-400",
    bgClass: "bg-violet-400/10 border-violet-400/20",
    glowClass: "group-hover:glow-violet",
    title: "HD Transparent PNG",
    description:
      "Download crystal-clear transparent PNGs with precise edge detection. Perfect for e-commerce, marketing, and creative projects.",
    badge: "Full HD",
  },
  {
    icon: Wand2,
    color: "emerald",
    colorClass: "text-emerald-400",
    bgClass: "bg-emerald-400/10 border-emerald-400/20",
    glowClass: "",
    title: "100% Automatic",
    description:
      "No manual selection or tedious masking. AI detects and removes any background automatically — from portraits to products.",
    badge: "Zero effort",
  },
  {
    icon: Shield,
    color: "cyan",
    colorClass: "text-cyan-400",
    bgClass: "bg-cyan-400/10 border-cyan-400/20",
    glowClass: "",
    title: "Privacy First",
    description:
      "Your images are processed securely and never stored on our servers. Your data stays yours — always.",
    badge: "Secure",
  },
  {
    icon: Layers,
    color: "violet",
    colorClass: "text-violet-400",
    bgClass: "bg-violet-400/10 border-violet-400/20",
    glowClass: "",
    title: "Any Subject",
    description:
      "Works beautifully on people, animals, products, cars, logos, and complex scenes. Our AI handles them all.",
    badge: "Universal",
  },
  {
    icon: DownloadCloud,
    color: "emerald",
    colorClass: "text-emerald-400",
    bgClass: "bg-emerald-400/10 border-emerald-400/20",
    glowClass: "",
    title: "No Account Needed",
    description:
      "Upload, process, download. That's it. No sign-up, no subscription required for your first images.",
    badge: "Free to try",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1, delayChildren: 0.1 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
  },
};

export default function FeatureCards() {
  return (
    <section id="features" className="relative z-10 py-24 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-border-bright text-xs font-semibold text-violet-400 mb-6">
            ✦ Why CutOut AI
          </div>
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-5"
            style={{ fontFamily: "'Clash Display', sans-serif" }}
          >
            Everything you need,
            <br />
            <span className="gradient-text">nothing you don&apos;t</span>
          </h2>
          <p className="text-[#8B92B3] text-lg max-w-xl mx-auto">
            Powerful AI background removal built for speed, quality, and
            simplicity.
          </p>
        </motion.div>

        {/* Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                variants={cardVariants}
                className={`group feature-card glass rounded-2xl p-6 border border-border cursor-default`}
              >
                {/* Icon & badge row */}
                <div className="flex items-start justify-between mb-5">
                  <div
                    className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-transform duration-300 group-hover:scale-110 ${feature.bgClass}`}
                  >
                    <Icon className={`w-5 h-5 ${feature.colorClass}`} />
                  </div>
                  <span
                    className={`text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full border ${feature.bgClass} ${feature.colorClass}`}
                  >
                    {feature.badge}
                  </span>
                </div>

                {/* Content */}
                <h3
                  className="text-lg font-bold text-white mb-3"
                  style={{ fontFamily: "'Clash Display', sans-serif" }}
                >
                  {feature.title}
                </h3>
                <p className="text-sm text-[#8B92B3] leading-relaxed">
                  {feature.description}
                </p>

                {/* Bottom hover line */}
                <div
                  className={`mt-5 h-px w-0 group-hover:w-full transition-all duration-500 rounded-full ${
                    feature.color === "cyan"
                      ? "bg-gradient-to-r from-cyan-400/60 to-transparent"
                      : feature.color === "violet"
                      ? "bg-gradient-to-r from-violet-400/60 to-transparent"
                      : "bg-gradient-to-r from-emerald-400/60 to-transparent"
                  }`}
                />
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
