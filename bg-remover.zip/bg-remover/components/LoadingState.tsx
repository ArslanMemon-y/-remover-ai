"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface LoadingStateProps {
  originalImage: string | null;
}

const steps = [
  { label: "Uploading image...", duration: 800 },
  { label: "Detecting edges & subjects...", duration: 1200 },
  { label: "Segmenting foreground...", duration: 1500 },
  { label: "Removing background...", duration: 1000 },
  { label: "Generating transparent PNG...", duration: 800 },
];

export default function LoadingState({ originalImage }: LoadingStateProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let stepIndex = 0;
    let progressValue = 0;

    const advanceStep = () => {
      if (stepIndex < steps.length - 1) {
        stepIndex++;
        setCurrentStep(stepIndex);
      }
    };

    // Advance steps
    const stepTimers: NodeJS.Timeout[] = [];
    let cumulativeTime = 0;
    steps.forEach((step, i) => {
      if (i === 0) return;
      cumulativeTime += steps[i - 1].duration;
      stepTimers.push(setTimeout(advanceStep, cumulativeTime));
    });

    // Smooth progress bar
    const progressInterval = setInterval(() => {
      progressValue = Math.min(progressValue + 0.8, 92);
      setProgress(progressValue);
    }, 100);

    return () => {
      stepTimers.forEach(clearTimeout);
      clearInterval(progressInterval);
    };
  }, []);

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Section heading */}
      <div className="text-center mb-10">
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold text-white mb-3"
          style={{ fontFamily: "'Clash Display', sans-serif" }}
        >
          AI is working its magic
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-[#8B92B3]"
        >
          Hang tight, this usually takes just a few seconds
        </motion.p>
      </div>

      {/* Main processing card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="glass rounded-3xl border border-border overflow-hidden"
      >
        {/* Image preview with scan effect */}
        <div className="relative aspect-video overflow-hidden bg-card">
          {originalImage ? (
            <>
              <img
                src={originalImage}
                alt="Processing"
                className="w-full h-full object-contain"
              />
              {/* Animated scan line */}
              <motion.div
                className="absolute inset-x-0 h-1"
                style={{
                  background:
                    "linear-gradient(90deg, transparent, rgba(34,211,238,0.8), transparent)",
                  boxShadow: "0 0 20px rgba(34,211,238,0.6)",
                }}
                animate={{ top: ["0%", "100%", "0%"] }}
                transition={{
                  duration: 2.5,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
              {/* Dark overlay */}
              <div className="absolute inset-0 bg-obsidian/40" />
              {/* Corner brackets */}
              {[
                "top-3 left-3 border-t-2 border-l-2 rounded-tl-lg",
                "top-3 right-3 border-t-2 border-r-2 rounded-tr-lg",
                "bottom-3 left-3 border-b-2 border-l-2 rounded-bl-lg",
                "bottom-3 right-3 border-b-2 border-r-2 rounded-br-lg",
              ].map((cls, i) => (
                <div
                  key={i}
                  className={`absolute w-6 h-6 border-cyan-400 ${cls}`}
                />
              ))}
            </>
          ) : (
            <div className="w-full h-full bg-card shimmer" />
          )}
        </div>

        {/* Progress section */}
        <div className="p-6 md:p-8">
          {/* Status */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {/* Spinner */}
              <div className="relative w-6 h-6">
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-transparent border-t-cyan-400"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                />
                <div className="absolute inset-1 rounded-full border border-border" />
              </div>
              <motion.span
                key={currentStep}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-sm font-medium text-[#F0F2FF]"
              >
                {steps[currentStep].label}
              </motion.span>
            </div>
            <span className="text-sm font-mono text-cyan-400">
              {Math.round(progress)}%
            </span>
          </div>

          {/* Progress bar */}
          <div className="h-2 bg-card rounded-full overflow-hidden border border-border mb-6">
            <motion.div
              className="h-full rounded-full progress-bar"
              style={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {/* Step indicators */}
          <div className="flex items-center gap-2">
            {steps.map((step, i) => (
              <div key={i} className="flex items-center gap-2">
                <div
                  className={`w-2 h-2 rounded-full transition-all duration-500 ${
                    i < currentStep
                      ? "bg-emerald-400"
                      : i === currentStep
                      ? "bg-cyan-400 animate-pulse"
                      : "bg-border"
                  }`}
                />
                {i < steps.length - 1 && (
                  <div
                    className={`h-px flex-1 transition-all duration-700 ${
                      i < currentStep ? "bg-emerald-400/50" : "bg-border"
                    }`}
                    style={{ width: "20px" }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* AI tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="mt-6 p-4 rounded-2xl bg-violet-500/5 border border-violet-500/20 flex items-start gap-3"
      >
        <span className="text-lg">💡</span>
        <p className="text-sm text-[#8B92B3]">
          <span className="text-violet-400 font-medium">Pro tip:</span> For best
          results, use images with a clear subject and good contrast against the
          background.
        </p>
      </motion.div>
    </div>
  );
}
