"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Download,
  RotateCcw,
  ImageIcon,
  CheckCircle2,
  SplitSquareHorizontal,
} from "lucide-react";
import toast from "react-hot-toast";

interface ResultPreviewProps {
  originalImage: string;
  processedImage: string;
  onReset: () => void;
}

type ViewMode = "split" | "original" | "result";

export default function ResultPreview({
  originalImage,
  processedImage,
  onReset,
}: ResultPreviewProps) {
  const [viewMode, setViewMode] = useState<ViewMode>("split");
  const [sliderPos, setSliderPos] = useState(50);
  const [isDraggingSlider, setIsDraggingSlider] = useState(false);

  const handleDownload = async () => {
    try {
      const link = document.createElement("a");
      link.href = processedImage;
      link.download = `cutout-ai-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success("Image downloaded!");
    } catch {
      toast.error("Download failed. Please try again.");
    }
  };

  const handleSliderMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingSlider) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(
      0,
      Math.min(e.touches[0].clientX - rect.left, rect.width)
    );
    setSliderPos((x / rect.width) * 100);
  };

  return (
    <div className="w-full max-w-5xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-400/10 border border-emerald-400/20 text-emerald-400 text-sm font-medium mb-4">
          <CheckCircle2 className="w-4 h-4" />
          Background removed successfully!
        </div>
        <h2
          className="text-3xl md:text-4xl font-bold text-white"
          style={{ fontFamily: "'Clash Display', sans-serif" }}
        >
          Your Result is Ready
        </h2>
      </motion.div>

      {/* View mode tabs */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex justify-center mb-6"
      >
        <div className="flex glass rounded-xl border border-border p-1 gap-1">
          {(
            [
              { id: "split", label: "Compare", icon: SplitSquareHorizontal },
              { id: "original", label: "Original", icon: ImageIcon },
              { id: "result", label: "Result", icon: CheckCircle2 },
            ] as const
          ).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setViewMode(id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                viewMode === id
                  ? "bg-card border border-border-bright text-white"
                  : "text-[#4A5070] hover:text-[#8B92B3]"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Image preview area */}
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15, duration: 0.5 }}
        className="glass rounded-3xl border border-border overflow-hidden mb-6"
      >
        {/* Split view with drag slider */}
        {viewMode === "split" && (
          <div
            className="relative w-full aspect-video cursor-col-resize select-none overflow-hidden"
            onMouseMove={handleSliderMove}
            onMouseDown={() => setIsDraggingSlider(true)}
            onMouseUp={() => setIsDraggingSlider(false)}
            onMouseLeave={() => setIsDraggingSlider(false)}
            onTouchMove={handleTouchMove}
          >
            {/* Original layer (right side) */}
            <div className="absolute inset-0">
              <img
                src={originalImage}
                alt="Original"
                className="w-full h-full object-contain bg-card"
              />
              <div className="absolute top-3 right-3 px-3 py-1 rounded-lg glass border border-border text-xs font-semibold text-[#8B92B3]">
                Original
              </div>
            </div>

            {/* Processed layer (left side, clipped) */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
            >
              <div className="absolute inset-0 checkerboard" />
              <img
                src={processedImage}
                alt="Result"
                className="absolute inset-0 w-full h-full object-contain"
              />
              <div className="absolute top-3 left-3 px-3 py-1 rounded-lg glass border border-border text-xs font-semibold text-cyan-400">
                Removed
              </div>
            </div>

            {/* Slider line */}
            <div
              className="absolute inset-y-0 w-0.5 bg-white/80 cursor-col-resize z-10"
              style={{ left: `${sliderPos}%` }}
            >
              {/* Handle */}
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-xl flex items-center justify-center cursor-col-resize">
                <div className="flex items-center gap-0.5">
                  <div className="w-0.5 h-3 bg-gray-400 rounded" />
                  <div className="w-0.5 h-3 bg-gray-400 rounded" />
                </div>
              </div>
            </div>

            {/* Drag hint */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg glass border border-border text-xs text-[#4A5070] pointer-events-none">
              ← Drag to compare →
            </div>
          </div>
        )}

        {/* Original view */}
        {viewMode === "original" && (
          <div className="relative aspect-video bg-card">
            <img
              src={originalImage}
              alt="Original"
              className="w-full h-full object-contain"
            />
          </div>
        )}

        {/* Result view */}
        {viewMode === "result" && (
          <div className="relative aspect-video checkerboard">
            <img
              src={processedImage}
              alt="Result"
              className="w-full h-full object-contain"
            />
          </div>
        )}
      </motion.div>

      {/* Action buttons */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col sm:flex-row items-center justify-center gap-4"
      >
        <button
          onClick={handleDownload}
          className="group flex items-center gap-3 px-8 py-4 rounded-xl btn-primary text-base font-semibold text-white min-w-[220px] justify-center"
        >
          <Download className="w-5 h-5 group-hover:animate-bounce" />
          Download HD PNG
        </button>

        <button
          onClick={onReset}
          className="flex items-center gap-2.5 px-8 py-4 rounded-xl border border-border-bright text-[#8B92B3] hover:text-white hover:border-[#3A4570] transition-all duration-200 text-base font-medium"
        >
          <RotateCcw className="w-4 h-4" />
          Remove Another
        </button>
      </motion.div>

      {/* File info strip */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 p-4 rounded-2xl glass border border-border flex items-center justify-between flex-wrap gap-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-white">Processing complete</p>
            <p className="text-xs text-[#4A5070]">
              Transparent PNG · Ready to download
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs text-[#4A5070]">
          <div className="w-2 h-2 rounded-full bg-emerald-400" />
          AI processing successful
        </div>
      </motion.div>
    </div>
  );
}
