"use client";

import { motion } from "framer-motion";
import { ArrowRight, Sparkles, CheckCircle2 } from "lucide-react";

interface HeroSectionProps {
  onGetStarted: () => void;
}

const staggerContainer = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.2,
    },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
  },
};

const perks = [
  "No registration required",
  "HD transparent PNG",
  "Powered by AI",
];

export default function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 pt-28 pb-16">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="max-w-4xl mx-auto text-center"
      >
        {/* Badge */}
        <motion.div variants={fadeUp} className="flex justify-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-border-bright text-xs font-semibold text-cyan-400 float-badge">
            <Sparkles className="w-3.5 h-3.5" />
            AI-Powered Background Removal
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={fadeUp}
          className="text-5xl md:text-7xl font-bold leading-[1.05] tracking-tight mb-6"
          style={{ fontFamily: "'Clash Display', sans-serif" }}
        >
          Remove Image{" "}
          <span className="relative">
            <span className="gradient-text">Backgrounds</span>
            {/* Underline accent */}
            <motion.span
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.8, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 origin-left"
            />
          </span>
          <br />
          <span className="text-[#F0F2FF]">Instantly with AI</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          variants={fadeUp}
          className="text-lg md:text-xl text-[#8B92B3] max-w-2xl mx-auto leading-relaxed mb-10"
        >
          Upload any photo and our AI will precisely cut out the background in
          seconds. Download a crisp, transparent PNG ready for any project.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          variants={fadeUp}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
        >
          <button
            onClick={onGetStarted}
            className="group flex items-center gap-2.5 px-7 py-4 rounded-xl btn-primary text-base font-semibold text-white min-w-[200px] justify-center"
          >
            Remove Background Free
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onGetStarted}
            className="flex items-center gap-2 px-7 py-4 rounded-xl border border-border-bright text-[#8B92B3] hover:text-white hover:border-[#3A4570] transition-all duration-200 text-base font-medium"
          >
            See how it works
          </button>
        </motion.div>

        {/* Perks */}
        <motion.div
          variants={fadeUp}
          className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2"
        >
          {perks.map((perk) => (
            <div
              key={perk}
              className="flex items-center gap-2 text-sm text-[#8B92B3]"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              {perk}
            </div>
          ))}
        </motion.div>

        {/* Stats row */}
        <motion.div
          variants={fadeUp}
          className="mt-16 grid grid-cols-3 gap-4 max-w-xl mx-auto"
        >
          {[
            { value: "5M+", label: "Images processed" },
            { value: "<3s", label: "Average time" },
            { value: "99%", label: "Accuracy" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="glass rounded-2xl p-4 border border-border"
            >
              <div
                className="text-2xl font-bold gradient-text-cyan mb-1"
                style={{ fontFamily: "'Clash Display', sans-serif" }}
              >
                {stat.value}
              </div>
              <div className="text-xs text-[#4A5070] font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Bottom gradient fade into upload section */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-obsidian to-transparent pointer-events-none" />
    </section>
  );
}
