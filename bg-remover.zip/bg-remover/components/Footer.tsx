"use client";

import { Scissors, Github, Twitter, Heart } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative z-10 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Top row */}
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-8 mb-10">
          {/* Brand */}
          <div className="flex flex-col items-center md:items-start gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center">
                <Scissors className="w-4 h-4 text-white" strokeWidth={2.5} />
              </div>
              <span
                className="text-lg font-bold tracking-tight text-white"
                style={{ fontFamily: "'Clash Display', sans-serif" }}
              >
                CutOut<span className="gradient-text-cyan">AI</span>
              </span>
            </div>
            <p className="text-sm text-[#4A5070] max-w-xs text-center md:text-left">
              AI-powered background removal for everyone. Fast, precise, and
              completely free to try.
            </p>
          </div>

          {/* Links */}
          <div className="flex gap-16">
            <div className="space-y-3">
              <p className="text-xs font-semibold text-[#8B92B3] uppercase tracking-widest">
                Product
              </p>
              {["Features", "Pricing", "API", "Changelog"].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="block text-sm text-[#4A5070] hover:text-[#8B92B3] transition-colors"
                >
                  {item}
                </a>
              ))}
            </div>
            <div className="space-y-3">
              <p className="text-xs font-semibold text-[#8B92B3] uppercase tracking-widest">
                Company
              </p>
              {["About", "Blog", "Privacy", "Terms"].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="block text-sm text-[#4A5070] hover:text-[#8B92B3] transition-colors"
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-gradient mb-6" />

        {/* Bottom row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#4A5070] flex items-center gap-1.5">
            Made with <Heart className="w-3.5 h-3.5 text-red-400 fill-red-400" /> by the CutOut AI team · © {year}
          </p>

          <div className="flex items-center gap-4">
            <a
              href="#"
              className="text-[#4A5070] hover:text-[#8B92B3] transition-colors"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href="#"
              className="text-[#4A5070] hover:text-[#8B92B3] transition-colors"
            >
              <Twitter className="w-4 h-4" />
            </a>
            <div className="flex items-center gap-2 text-xs text-[#4A5070]">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              All systems operational
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
