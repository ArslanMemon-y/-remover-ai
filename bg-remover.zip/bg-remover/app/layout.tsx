import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "react-hot-toast";

export const metadata: Metadata = {
  title: "CutOut AI — Remove Image Backgrounds Instantly",
  description:
    "AI-powered background removal. Upload any image and get a clean transparent PNG in seconds. No skills required.",
  keywords: ["background remover", "AI", "transparent PNG", "image editing"],
  openGraph: {
    title: "CutOut AI — Remove Image Backgrounds Instantly",
    description: "AI-powered background removal in seconds.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://api.fontshare.com" />
      </head>
      <body className="noise antialiased">
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: "#181C2A",
              color: "#F0F2FF",
              border: "1px solid #2A3050",
              borderRadius: "12px",
              fontSize: "14px",
              fontFamily: "'DM Sans', sans-serif",
            },
            success: {
              iconTheme: { primary: "#34D399", secondary: "#181C2A" },
            },
            error: {
              iconTheme: { primary: "#F87171", secondary: "#181C2A" },
            },
          }}
        />
        {children}
      </body>
    </html>
  );
}
