"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import UploadBox from "@/components/UploadBox";
import LoadingState from "@/components/LoadingState";
import ResultPreview from "@/components/ResultPreview";
import FeatureCards from "@/components/FeatureCards";
import Footer from "@/components/Footer";
import AnimatedBackground from "@/components/AnimatedBackground";
import toast from "react-hot-toast";

type AppState = "idle" | "processing" | "result";

export default function Home() {
  const [appState, setAppState] = useState<AppState>("idle");
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleImageUpload = async (file: File) => {
    if (isSubmitting) return;

    // Validate file type
    const validTypes = ["image/png", "image/jpg", "image/jpeg", "image/webp"];
    if (!validTypes.includes(file.type)) {
      toast.error("Please upload a PNG, JPG, JPEG, or WEBP image.");
      return;
    }

    // Validate file size (10MB max)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("File too large. Maximum size is 10MB.");
      return;
    }

    // Show original image preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setOriginalImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    setIsSubmitting(true);
    setAppState("processing");
    setProcessedImage(null);

    try {
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch("/api/remove-background", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to remove background.");
      }

      const blob = await response.blob();
      const processedUrl = URL.createObjectURL(blob);
      setProcessedImage(processedUrl);
      setAppState("result");
      toast.success("Background removed successfully!");
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Something went wrong.";
      toast.error(message);
      setAppState("idle");
      setOriginalImage(null);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setAppState("idle");
    setOriginalImage(null);
    setProcessedImage(null);
  };

  const scrollToUpload = () => {
    document.getElementById("upload-section")?.scrollIntoView({
      behavior: "smooth",
    });
  };

  return (
    <main className="min-h-screen bg-obsidian relative">
      <AnimatedBackground />
      <Navbar />

      {/* Hero */}
      <HeroSection onGetStarted={scrollToUpload} />

      {/* Upload / Processing / Result Section */}
      <section id="upload-section" className="relative z-10 py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <AnimatePresence mode="wait">
            {appState === "idle" && (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <UploadBox onUpload={handleImageUpload} isLoading={isSubmitting} />
              </motion.div>
            )}

            {appState === "processing" && (
              <motion.div
                key="loading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              >
                <LoadingState originalImage={originalImage} />
              </motion.div>
            )}

            {appState === "result" && processedImage && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              >
                <ResultPreview
                  originalImage={originalImage!}
                  processedImage={processedImage}
                  onReset={handleReset}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Divider */}
      <div className="divider-gradient mx-auto max-w-4xl" />

      {/* Features */}
      <FeatureCards />

      {/* Footer */}
      <Footer />
    </main>
  );
}
