import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    // Check API key exists
    const apiKey = process.env.REMOVE_BG_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { message: "API key not configured. Please set REMOVE_BG_API_KEY in .env.local" },
        { status: 500 }
      );
    }

    // Parse incoming form data
    const formData = await request.formData();
    const imageFile = formData.get("image") as File | null;

    if (!imageFile) {
      return NextResponse.json(
        { message: "No image file provided." },
        { status: 400 }
      );
    }

    // Validate file type
    const validTypes = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
    if (!validTypes.includes(imageFile.type)) {
      return NextResponse.json(
        { message: "Invalid file type. Please upload PNG, JPG, or WEBP." },
        { status: 400 }
      );
    }

    // Convert file to buffer
    const imageBuffer = await imageFile.arrayBuffer();
    const imageBytes = new Uint8Array(imageBuffer);

    // Build multipart form data for remove.bg API
    const removeBgForm = new FormData();

    // Append the image as a blob
    const imageBlob = new Blob([imageBytes], { type: imageFile.type });
    removeBgForm.append("image_file", imageBlob, imageFile.name || "image.png");
    removeBgForm.append("size", "auto"); // Use auto sizing (free: preview, paid: full)

    // Call remove.bg API
    const removeBgResponse = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: {
        "X-Api-Key": apiKey,
      },
      body: removeBgForm,
    });

    // Handle remove.bg API errors
    if (!removeBgResponse.ok) {
      let errorMessage = "Failed to process image.";

      try {
        const errorData = await removeBgResponse.json();
        if (errorData.errors && errorData.errors.length > 0) {
          errorMessage = errorData.errors[0].title || errorMessage;
        }
      } catch {
        // If response isn't JSON, use status-based message
        if (removeBgResponse.status === 402) {
          errorMessage = "API credit limit reached. Please check your remove.bg account.";
        } else if (removeBgResponse.status === 403) {
          errorMessage = "Invalid API key. Please check your REMOVE_BG_API_KEY.";
        } else if (removeBgResponse.status === 429) {
          errorMessage = "Too many requests. Please wait a moment and try again.";
        }
      }

      return NextResponse.json({ message: errorMessage }, { status: removeBgResponse.status });
    }

    // Get the processed image as a buffer
    const processedImageBuffer = await removeBgResponse.arrayBuffer();

    // Return the transparent PNG
    return new NextResponse(processedImageBuffer, {
      status: 200,
      headers: {
        "Content-Type": "image/png",
        "Content-Disposition": "attachment; filename=cutout-ai-result.png",
        "Cache-Control": "no-store",
      },
    });
  } catch (error: unknown) {
    console.error("Background removal error:", error);
    return NextResponse.json(
      { message: "Internal server error. Please try again." },
      { status: 500 }
    );
  }
}
