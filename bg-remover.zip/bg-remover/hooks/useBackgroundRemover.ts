"use client";

import { useState, useCallback, useRef } from "react";
import toast from "react-hot-toast";

export type ProcessingState = "idle" | "processing" | "success" | "error";

interface UseBackgroundRemoverReturn {
  state: ProcessingState;
  originalImage: string | null;
  processedImage: string | null;
  error: string | null;
  processImage: (file: File) => Promise<void>;
  reset: () => void;
  isProcessing: boolean;
}

export function useBackgroundRemover(): UseBackgroundRemoverReturn {
  const [state, setState] = useState<ProcessingState>("idle");
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const processImage = useCallback(async (file: File) => {
    // Prevent duplicate submissions
    if (state === "processing") return;

    // Cancel any in-flight request
    abortControllerRef.current?.abort();
    abortControllerRef.current = new AbortController();

    // Show original preview immediately
    const reader = new FileReader();
    reader.onload = (e) => setOriginalImage(e.target?.result as string);
    reader.readAsDataURL(file);

    setState("processing");
    setError(null);
    setProcessedImage(null);

    try {
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch("/api/remove-background", {
        method: "POST",
        body: formData,
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.message || `Server error: ${response.status}`
        );
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);

      setProcessedImage(url);
      setState("success");
      toast.success("Background removed successfully!");
    } catch (err: unknown) {
      if (err instanceof Error && err.name === "AbortError") return;

      const message =
        err instanceof Error ? err.message : "An unexpected error occurred.";
      setError(message);
      setState("error");
      toast.error(message);
    }
  }, [state]);

  const reset = useCallback(() => {
    abortControllerRef.current?.abort();
    // Clean up object URL to prevent memory leaks
    if (processedImage) URL.revokeObjectURL(processedImage);
    setState("idle");
    setOriginalImage(null);
    setProcessedImage(null);
    setError(null);
  }, [processedImage]);

  return {
    state,
    originalImage,
    processedImage,
    error,
    processImage,
    reset,
    isProcessing: state === "processing",
  };
}
